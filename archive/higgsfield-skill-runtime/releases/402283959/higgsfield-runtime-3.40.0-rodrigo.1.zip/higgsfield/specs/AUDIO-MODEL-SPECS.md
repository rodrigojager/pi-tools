# Model Specs (generated)

**Snapshot: 2026-09-26** · source `specs/models_explore_snapshot_audio_2026-09-26.json` · cached platform reference; verify live tool schemas before generation.

| Model | id (aliases) | Duration | Resolutions | Modes | Aspect ratios | Media roles | Constraints |
|-------|--------------|----------|-------------|-------|---------------|-------------|-------------|
| Inworld Text to Speech | inworld_text_to_speech | — | — | — | — | — | — |
| Mirelo Text to Audio | mirelo_text_to_audio | — | — | — | — | — | — |
| Qwen Audio 3.0 TTS Flash | qwen_audio_tts | — | — | — | — | — | — |
| Seed Audio 1.0 | seed_audio | — | — | — | — | medias: image_references, audio_references | — |
| Sonilo Music | sonilo_music | — | — | — | — | — | — |
| Text to Speech V2 | text2speech_v2 | — | — | — | — | — | — |

Full per-model parameter schemas live in `specs/audio-model-specs.yaml` / `specs/audio-model-specs.json`.

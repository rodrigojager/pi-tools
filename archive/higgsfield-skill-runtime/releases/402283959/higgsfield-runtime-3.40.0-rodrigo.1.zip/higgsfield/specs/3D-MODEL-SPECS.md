# Model Specs (generated)

**Snapshot: 2026-09-26** · source `specs/models_explore_snapshot_3d_2026-09-26.json` · cached platform reference; verify live tool schemas before generation.

| Model | id (aliases) | Duration | Resolutions | Modes | Aspect ratios | Media roles | Constraints |
|-------|--------------|----------|-------------|-------|---------------|-------------|-------------|
| 3D Rigging | 3d_rigging | — | — | — | — | — | — |
| Hunyuan 3D v3.1 Text to 3D | hunyuan3d_v3_1_text_to_3d | — | — | std, pro | — | — | — |
| Hunyuan3D v3 Image to 3D | hunyuan3d_v3_image_to_3d | — | — | — | — | medias: image_references | — |
| Image to 3D | image_to_3d | — | — | — | — | medias: image | — |
| Image to 3D | meshy_image_to_3d | — | — | — | — | medias: image | — |
| Multi-Image to 3D | meshy_multi_image_to_3d | — | — | — | — | medias: image | — |
| 3D Rigging | meshy_rigging | — | — | — | — | — | — |
| Meshy 5 Remesh | meshy_v5_remesh | — | — | — | — | — | — |
| Meshy 5 Retexture | meshy_v5_retexture | — | — | — | — | — | — |
| Meshy 6 Text to 3D | meshy_v6_text_to_3d | — | — | preview, full | — | — | — |
| Meshy 7 Image to 3D | meshy_v7_image_to_3d | — | — | — | — | medias: image_references | — |
| Multi-Image to 3D | multi_image_to_3d | — | — | — | — | medias: image | — |
| SAM 3 3D Objects | sam_3_3d | — | — | — | — | medias: image | — |
| 3D Body | sam_3_3d_body | — | — | — | — | medias: image_references | — |
| Text to 3D | tripo_3d | — | — | — | — | — | — |
| Tripo H3.1 Image to 3D | tripo_h3_1_image_to_3d | — | — | — | — | medias: image_references | — |
| Tripo H3.1 Multiview to 3D | tripo_h3_1_multiview_to_3d | — | — | — | — | medias: image_references | — |

Full per-model parameter schemas live in `specs/3d-model-specs.yaml` / `specs/3d-model-specs.json`.
